# Tabela - Disputa de Xadrez!

A Pen created on CodePen.io. Original URL: [https://codepen.io/Red0Dev/pen/qBygRLa](https://codepen.io/Red0Dev/pen/qBygRLa).

